***************************************
* TemplateWorld.com - Licensing Information!
*
***************************************

* If you purchase or use any of TemplateWorld.com products, it will be understood that you have read and accepted the following terms and conditions.
*
* Don'ts:
*
* - You are NOT allowed to sell/giveaway our template(s) to 3rd parties.
* - You will NOT claim that you or any of your associates have designed our template(s).
* - You will NOT include/bundle our template(s) within your products and sell them without written permission from TemplateWorld.com.
* - You will NOT hand out our template(s) even after you have performed modifications on it. However, you may do the same, only after all images and design objects are substituted and the template looks considerably different from the original template.
*
* * WARNING - All our template(s) and digital work(s) have been filed with the International Copyright Offices. You stand a very HIGH chance of being prosecuted if you abuse our rights and misuse your rights as an owner.
*
* Dos:
*
* - You can freely use the templates for your personal website.
* - You can freely use the templates for your company/corporate website.
* - You can freely use the templates for your client's websites. *
*
* * By using the word 'freely' in this case, TemplateWorld.com allows you to use the templates in a maximum of Fifty (50) projects for "6 Months Membership Subscribers" and hundred (100) projects for "1 Year Membership Subscribers". *
*
* * In an event that you use our templates in more than specified number of client projects, please remember that you will be required to pay for an extra membership account. This part of the license has been included to prevent excessive use of a single or group template(s).
*
* ATTENTION: If you are to using our templates to design websites for your commercial clients, please advise your clients IN ADVANCE not to distribute our templates.
* If they do not agree, please inform them that they will definitely have to deal with legal disputes.
*
* For web developer(s) and consultant(s)
*
* You are free to use the templates purchased from us to design your customer's websites.
*
* - However the templates may not be resold in any sort of collection, such as distributing to a third party via CD, diskette, or letting others to download them from your or linked or any website(s).
* - You also may not edit the template and subsequently sell/distribute it in any way.
*
*
* REDISTRIBUTIONS
*
* Dos: Our templates may be used for your own and/or your client's websites.
*
* Don'ts: You may not put them on a diskette, CD, website or any other medium and present them for redistribution or resale.
*
*
Our Attorney can be reached at: legal@templateworld.com

***************************************
* TemplateWorld.com - Licensing Information!
*
***************************************